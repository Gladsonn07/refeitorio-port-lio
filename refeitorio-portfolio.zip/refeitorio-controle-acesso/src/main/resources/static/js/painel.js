// Relógio em tempo real
function atualizarRelogio() {
    const agora = new Date();
    const hora = agora.toLocaleTimeString('pt-BR');
    const relogio = document.getElementById('relogio');
    if (relogio) relogio.textContent = hora;
}
atualizarRelogio();
setInterval(atualizarRelogio, 1000);

// Auto-atualiza a página a cada 30 segundos se for hoje
const dataInput = document.querySelector('input[name="data"]');
const hoje = new Date().toISOString().split('T')[0];
if (!dataInput || dataInput.value === hoje || dataInput.value === '') {
    setInterval(() => location.reload(), 30000);
}
