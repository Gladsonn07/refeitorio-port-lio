package com.gladson.refeitorio.controller;

import com.gladson.refeitorio.dto.AcessoRequestDTO;
import com.gladson.refeitorio.model.Acesso;
import com.gladson.refeitorio.service.AcessoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@Slf4j
public class AcessoApiController {

    private final AcessoService service;

    @Value("${api.secret.key}")
    private String apiSecretKey;

    // ── Recebe acesso do agente Python ───────────────────────

    @PostMapping("/acesso")
    public ResponseEntity<?> registrarAcesso(
            @RequestHeader("X-API-Key") String apiKey,
            @Valid @RequestBody AcessoRequestDTO dto
    ) {
        if (!apiSecretKey.equals(apiKey)) {
            log.warn("⚠️  Tentativa de acesso com chave inválida");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("erro", "Chave de API inválida"));
        }

        Acesso salvo = service.registrar(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
                "id",         salvo.getId(),
                "colaborador", salvo.getColaborador(),
                "refeicao",   salvo.getRefeicao(),
                "resultado",  salvo.getResultado(),
                "dataHora",   salvo.getDataHora().toString()
        ));
    }

    // ── Consultas REST ────────────────────────────────────────

    @GetMapping("/acessos/hoje")
    public ResponseEntity<List<Acesso>> acessosHoje() {
        return ResponseEntity.ok(service.buscarHoje());
    }

    @GetMapping("/acessos/totais")
    public ResponseEntity<Map<String, Long>> totaisHoje() {
        return ResponseEntity.ok(service.totaisHoje());
    }

    // ── Exportar Excel via API ────────────────────────────────

    @GetMapping("/exportar")
    public ResponseEntity<byte[]> exportar(
            @RequestParam(defaultValue = "") String data
    ) throws IOException {
        LocalDate localDate = data.isBlank()
                ? LocalDate.now()
                : LocalDate.parse(data, DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        byte[] excel = service.exportarExcel(localDate);
        String nomeArquivo = "refeitorio_" + localDate + ".xlsx";

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + nomeArquivo)
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(excel);
    }

    // ── Health check ──────────────────────────────────────────

    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
                "status", "OK",
                "sistema", "Monitor de Refeitório"
        ));
    }
}
