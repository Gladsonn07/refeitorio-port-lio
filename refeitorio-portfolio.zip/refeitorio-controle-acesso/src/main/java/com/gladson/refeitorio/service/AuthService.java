package com.gladson.refeitorio.service;

import com.gladson.refeitorio.model.Usuario;
import com.gladson.refeitorio.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private UsuarioRepository repository;

    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public Usuario autenticar(String username, String password) {
        Usuario user = repository.findByUsername(username);
        // Verifica se o usuário existe E se a senha confere com o hash salvo
        if (user != null && encoder.matches(password, user.getPassword())) {
            return user;
        }
        return null; // Retorna null se não encontrar ou se a senha estiver errada
    }
}