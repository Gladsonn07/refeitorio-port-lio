package com.gladson.refeitorio.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class AuthInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        String uri = request.getRequestURI();
        
        // Libera a tela de login, o envio de dados do Python (API) e o visual (css/img)
        if (uri.endsWith("/login") || uri.endsWith("/logout") || uri.contains("/css/") || uri.contains("/img/") || uri.contains("/api/")) {
            return true; 
        }
        
        // Se tentar acessar outra coisa e não estiver logado, bloqueia e manda pro login
        if (request.getSession().getAttribute("usuarioLogado") == null) {
            response.sendRedirect("/login");
            return false;
        }
        
        return true;
    }
}
