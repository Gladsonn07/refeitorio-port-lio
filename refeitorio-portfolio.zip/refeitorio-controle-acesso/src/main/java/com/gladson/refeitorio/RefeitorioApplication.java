package com.gladson.refeitorio;

import com.gladson.refeitorio.model.Usuario;
import com.gladson.refeitorio.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootApplication
public class RefeitorioApplication {

    public static void main(String[] args) {
        SpringApplication.run(RefeitorioApplication.class, args);
    }

    // Senha inicial do usuário RH — defina via variável de ambiente
    // RH_INITIAL_PASSWORD antes do primeiro start em produção.
    @Bean
    public CommandLineRunner run(
            UsuarioRepository repository,
            @Value("${rh.initial.password:troque-esta-senha}") String senhaInicial
    ) {
        return args -> {
            if (repository.findByUsername("rh") == null) {
                Usuario rh = new Usuario();
                rh.setUsername("rh");
                rh.setPassword(new BCryptPasswordEncoder().encode(senhaInicial));
                repository.save(rh);
                System.out.println("Usuário RH criado. Lembre-se de trocar a senha inicial.");
            }
        };
    }
}