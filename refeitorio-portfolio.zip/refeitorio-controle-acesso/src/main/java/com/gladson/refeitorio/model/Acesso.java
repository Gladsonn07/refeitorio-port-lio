package com.gladson.refeitorio.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.time.LocalDateTime;

@Entity
@Table(
    name = "acessos",
    indexes = {
        // Acelera a busca do relatório diário para o Excel
        @Index(name = "idx_acesso_data_hora", columnList = "data_hora"),
        // Acelera a verificação de registros duplicados no Service
        @Index(name = "idx_acesso_duplicidade", columnList = "matricula, refeicao, data_hora")
    }
)
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Acesso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String colaborador;

    @Column(nullable = false, length = 50)
    private String matricula;

    @Column(nullable = false, length = 50)
    private String refeicao;

    @Column(nullable = false, length = 50)
    private String resultado;

    @Column(name = "data_hora", nullable = false)
    private LocalDateTime dataHora;

    @Column(name = "terminal_id", length = 50)
    private String terminalId;
}
