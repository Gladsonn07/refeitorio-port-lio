package com.gladson.refeitorio.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class AcessoRequestDTO {

    @NotBlank(message = "Nome do colaborador é obrigatório")
    private String colaborador;

    @NotBlank(message = "Matrícula é obrigatória")
    private String matricula;

    @NotBlank(message = "Refeição é obrigatória")
    private String refeicao;

    private String resultado;
    private String terminalId;
}