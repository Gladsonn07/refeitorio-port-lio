package com.gladson.refeitorio.service;

import com.gladson.refeitorio.dto.AcessoRequestDTO;
import com.gladson.refeitorio.model.Acesso;
import com.gladson.refeitorio.repository.AcessoRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AcessoService {

    private final AcessoRepository repository;

    private static final DateTimeFormatter HORA_FMT = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final DateTimeFormatter DATA_FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private static final LocalTime INICIO_OPERACAO = LocalTime.of(5, 0);
    private static final LocalTime FIM_OPERACAO    = LocalTime.of(20, 0);

    private record Refeicao(String nome, LocalTime inicio, LocalTime fim) {}
    private static final List<Refeicao> REFEICOES = List.of(
        new Refeicao("Café da Manhã", LocalTime.of(5,  0), LocalTime.of(8,  0)),
        new Refeicao("Almoço",        LocalTime.of(11, 0), LocalTime.of(13, 0)),
        new Refeicao("Jantar",        LocalTime.of(18, 0), LocalTime.of(20, 0))
    );

    public Acesso registrar(AcessoRequestDTO dto) {
        LocalDateTime momentoDoAcesso = LocalDateTime.now();

        LocalDate hoje  = momentoDoAcesso.toLocalDate();
        LocalTime agora = momentoDoAcesso.toLocalTime();

        if (agora.isBefore(INICIO_OPERACAO) || agora.isAfter(FIM_OPERACAO)) {
            log.info("⏭️  {} — fora da janela de operação, não registrado.", dto.getColaborador());
            return null;
        }

        String refeicao  = dto.getRefeicao();
        String resultado = dto.getResultado() != null ? dto.getResultado() : "Acesso OK";

        if (!"Fora do Horário".equals(refeicao)) {
            final String refeicaoCopy = refeicao;
            boolean dentroFaixa = REFEICOES.stream()
                .anyMatch(r -> r.nome().equals(refeicaoCopy) &&
                               !agora.isBefore(r.inicio()) &&
                               !agora.isAfter(r.fim()));
            if (!dentroFaixa) {
                refeicao  = "Fora do Horário";
                resultado = "Fora do Horário";
            }
        }

        if ("Acesso OK".equals(resultado) && !"—".equals(dto.getMatricula())) {
            boolean duplicado = repository.existsByMatriculaAndRefeicaoAndData(
                    dto.getMatricula(), refeicao, hoje);
            if (duplicado) {
                resultado = "Acesso Duplicado";
                log.warn("🔴 DUPLICADO: {} já registrou '{}' hoje", dto.getColaborador(), refeicao);
            }
        }

        Acesso acesso = Acesso.builder()
                .colaborador(dto.getColaborador())
                .matricula(dto.getMatricula())
                .refeicao(refeicao)
                .resultado(resultado)
                .terminalId(dto.getTerminalId() != null ? dto.getTerminalId() : "TERMINAL-01")
                .dataHora(momentoDoAcesso)
                .build();

        Acesso salvo = repository.save(acesso);
        log.info("✅ {} | {} | {} | {}", salvo.getColaborador(), salvo.getRefeicao(),
                salvo.getDataHora().format(HORA_FMT), resultado);
        return salvo;
    }

    public List<Acesso> buscarHoje() {
        return repository.findByData(LocalDate.now());
    }

    public List<Acesso> buscarPorData(LocalDate data) {
        return repository.findByData(data);
    }

    public List<Acesso> buscarPorDataERefeicao(LocalDate data, String refeicao) {
        return repository.findByDataAndRefeicao(data, refeicao);
    }

    public Map<String, Long> totaisHoje() {
        return repository.countByRefeicaoAndData(LocalDate.now())
                .stream()
                .collect(Collectors.toMap(o -> (String) o[0], o -> (Long) o[1]));
    }

    public byte[] exportarExcel(LocalDate data) throws IOException {
        List<Acesso> acessos = repository.findByData(data);

        try (XSSFWorkbook wb = new XSSFWorkbook();
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            XSSFCellStyle estiloOk   = criarEstiloLinha(wb, "C8E6C9");
            XSSFCellStyle estiloDup  = criarEstiloLinha(wb, "FFCDD2");
            XSSFCellStyle estiloDesc = criarEstiloLinha(wb, "FFE0B2");
            XSSFCellStyle estiloFora = criarEstiloLinha(wb, "EF9A9A");
            XSSFCellStyle estiloPar  = criarEstiloLinha(wb, "EEF2FF");
            XSSFCellStyle estiloImpar= criarEstiloLinha(wb, "FFFFFF");

            // Aba "Outros" adicionada para prevenir perda de dados anômalos
            String[] ordemAbas = {"Café da Manhã", "Almoço", "Jantar", "Fora do Horário", "Outros"};
            String[] emojis    = {"☕ Café da Manhã", "🍽️ Almoço", "🌙 Jantar", "⚠️ Fora do Horário", "❓ Outros"};
            String[] coresAba  = {"FF8F00", "1A237E", "1B5E20", "B71C1C", "757575"};

            Map<String, List<Acesso>> porRefeicao = acessos.stream()
                    .collect(Collectors.groupingBy(a -> {
                        String ref = a.getRefeicao();
                        return List.of("Café da Manhã", "Almoço", "Jantar", "Fora do Horário").contains(ref) 
                                ? ref : "Outros";
                    }));

            for (int i = 0; i < ordemAbas.length; i++) {
                String ref  = ordemAbas[i];
                String nome = emojis[i];
                List<Acesso> lista = porRefeicao.getOrDefault(ref, List.of());

                // Só cria a aba se houver registros nela (ou se for uma aba padrão)
                if (lista.isEmpty() && "Outros".equals(ref)) continue;

                XSSFSheet ws = wb.createSheet(nome);
                XSSFCellStyle headerAba = criarEstiloHeader(wb, coresAba[i]);

                String[] cols    = {"COLABORADOR", "HORÁRIO", "MATRÍCULA", "RESULTADO"};
                int[]    larguras = {9000, 3500, 4000, 5500};
                Row header = ws.createRow(0);
                header.setHeightInPoints(22);
                for (int j = 0; j < cols.length; j++) {
                    Cell cel = header.createCell(j);
                    cel.setCellValue(cols[j]);
                    cel.setCellStyle(headerAba);
                    ws.setColumnWidth(j, larguras[j]);
                }

                int rowNum = 1;
                for (Acesso a : lista) {
                    Row row = ws.createRow(rowNum++);
                    row.setHeightInPoints(18);

                    // Proteção contra NullPointerException
                    String resSeguro = a.getResultado() != null ? a.getResultado() : "Desconhecido";

                    XSSFCellStyle corRes = switch (resSeguro) {
                        case "Acesso OK"        -> estiloOk;
                        case "Acesso Duplicado" -> estiloDup;
                        case "Fora do Horário"  -> estiloFora;
                        default                 -> estiloDesc;
                    };
                    XSSFCellStyle corLinha = rowNum % 2 == 0 ? estiloPar : estiloImpar;

                    escrever(row, 0, a.getColaborador(),               corLinha);
                    escrever(row, 1, a.getDataHora().format(HORA_FMT), corLinha);
                    escrever(row, 2, a.getMatricula(),                 corLinha);
                    escrever(row, 3, resSeguro,                        corRes);
                }
            }

            criarAbaSobre(wb, data);
            wb.write(out);
            return out.toByteArray();
        }
    }

    private void escrever(Row row, int col, String valor, CellStyle estilo) {
        Cell cel = row.createCell(col);
        cel.setCellValue(valor != null ? valor : "—");
        cel.setCellStyle(estilo);
    }

    private XSSFCellStyle criarEstiloHeader(XSSFWorkbook wb, String hexCor) {
        XSSFCellStyle estilo = wb.createCellStyle();
        estilo.setFillForegroundColor(new XSSFColor(hexToBytes(hexCor), null));
        estilo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        estilo.setAlignment(HorizontalAlignment.CENTER);
        estilo.setVerticalAlignment(VerticalAlignment.CENTER);
        setBorda(estilo);
        XSSFFont fonte = wb.createFont();
        fonte.setBold(true);
        fonte.setColor(new XSSFColor(new byte[]{(byte)255,(byte)255,(byte)255}, null));
        fonte.setFontHeightInPoints((short) 11);
        fonte.setFontName("Calibri");
        estilo.setFont(fonte);
        return estilo;
    }

    private XSSFCellStyle criarEstiloLinha(XSSFWorkbook wb, String hexCor) {
        XSSFCellStyle estilo = wb.createCellStyle();
        estilo.setFillForegroundColor(new XSSFColor(hexToBytes(hexCor), null));
        estilo.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        estilo.setAlignment(HorizontalAlignment.CENTER);
        estilo.setVerticalAlignment(VerticalAlignment.CENTER);
        setBorda(estilo);
        XSSFFont fonte = wb.createFont();
        fonte.setFontName("Calibri");
        fonte.setFontHeightInPoints((short) 11);
        estilo.setFont(fonte);
        return estilo;
    }

    private void setBorda(XSSFCellStyle estilo) {
        estilo.setBorderTop(BorderStyle.THIN);
        estilo.setBorderBottom(BorderStyle.THIN);
        estilo.setBorderLeft(BorderStyle.THIN);
        estilo.setBorderRight(BorderStyle.THIN);
    }

    private byte[] hexToBytes(String hex) {
        int r = Integer.parseInt(hex.substring(0, 2), 16);
        int g = Integer.parseInt(hex.substring(2, 4), 16);
        int b = Integer.parseInt(hex.substring(4, 6), 16);
        return new byte[]{(byte) r, (byte) g, (byte) b};
    }

    private void criarAbaSobre(XSSFWorkbook wb, LocalDate data) {
        XSSFSheet ws = wb.createSheet("Sobre");
        ws.setColumnWidth(0, 8000);
        ws.setColumnWidth(1, 12000);

        XSSFCellStyle h = criarEstiloHeader(wb, "1A237E");
        XSSFCellStyle p = criarEstiloLinha(wb, "E8EAF6");
        XSSFCellStyle b = criarEstiloLinha(wb, "FFFFFF");

        Row titulo = ws.createRow(0);
        titulo.setHeightInPoints(30);
        Cell cel = titulo.createCell(0);
        cel.setCellValue("SISTEMA DE CONTROLE DE REFEITÓRIO");
        cel.setCellStyle(h);
        ws.addMergedRegion(new org.apache.poi.ss.util.CellRangeAddress(0, 0, 0, 1));

        String[][] infos = {
            {"Desenvolvido por",  "Gladson"},
            {"Equipamento",       "AiFace / Safe SF-1000 A"},
            {"Versão",            "Java + Spring Boot + PostgreSQL"},
            {"Data do relatório", data.format(DATA_FMT)},
            {"Gerado em",         LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"))},
        };

        for (int i = 0; i < infos.length; i++) {
            Row row = ws.createRow(i + 1);
            row.setHeightInPoints(20);
            XSSFCellStyle est = i % 2 == 0 ? p : b;
            escrever(row, 0, infos[i][0], est);
            escrever(row, 1, infos[i][1], est);
        }
    }
}
