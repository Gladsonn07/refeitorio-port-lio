package com.gladson.refeitorio.controller;

import com.gladson.refeitorio.model.Usuario;
import com.gladson.refeitorio.service.AuthService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AuthController {

    @Autowired
    private AuthService authService;

    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, HttpSession session, Model model) {
        Usuario user = authService.autenticar(username, password);
        if (user != null) {
            session.setAttribute("usuarioLogado", user);
            return "redirect:/"; // Redireciona para o painel após o sucesso
        }
        model.addAttribute("erro", "Usuário ou senha incorretos!");
        return "login"; // Volta para a tela de login se errar a senha
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate(); // Destrói a sessão e sai do sistema
        return "redirect:/login";
    }
}
