package com.gladson.refeitorio.controller;

import com.gladson.refeitorio.model.Acesso;
import com.gladson.refeitorio.service.AcessoService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequiredArgsConstructor
public class PainelController {

    private final AcessoService service;

    private static final DateTimeFormatter DATA_FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    @GetMapping("/")
    public String painel(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate data,
            @RequestParam(required = false) String refeicao,
            Model model
    ) {
        LocalDate dataConsulta = data != null ? data : LocalDate.now();

        List<Acesso> acessos = (refeicao != null && !refeicao.isBlank())
                ? service.buscarPorDataERefeicao(dataConsulta, refeicao)
                : service.buscarPorData(dataConsulta);

        Map<String, Long> totais = service.totaisHoje();

        // Separa por resultado para estatísticas
        long totalOk  = acessos.stream().filter(a -> "Acesso OK".equals(a.getResultado())).count();
        long totalDup = acessos.stream().filter(a -> "Acesso Duplicado".equals(a.getResultado())).count();
        long totalDesc= acessos.stream().filter(a -> "Desconhecido".equals(a.getResultado())).count();

        model.addAttribute("acessos",       acessos);
        model.addAttribute("dataConsulta",  dataConsulta);
        model.addAttribute("dataFormatada", dataConsulta.format(DATA_FMT));
        model.addAttribute("refeicaoFiltro",refeicao != null ? refeicao : "");
        model.addAttribute("totais",        totais);
        model.addAttribute("totalOk",       totalOk);
        model.addAttribute("totalDup",      totalDup);
        model.addAttribute("totalDesc",     totalDesc);
        model.addAttribute("hoje",          LocalDate.now());

        return "painel";
    }

    @GetMapping("/exportar")
    public ResponseEntity<byte[]> exportar(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate data
    ) throws IOException {
        LocalDate dataExport = data != null ? data : LocalDate.now();
        byte[] excel = service.exportarExcel(dataExport);
        String nome  = "refeitorio_" + dataExport + ".xlsx";

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + nome)
                .contentType(MediaType.parseMediaType(
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(excel);
    }
}
