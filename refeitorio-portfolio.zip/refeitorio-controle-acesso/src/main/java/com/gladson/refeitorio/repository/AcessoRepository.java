package com.gladson.refeitorio.repository;

import com.gladson.refeitorio.model.Acesso;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AcessoRepository extends JpaRepository<Acesso, Long> {

    // Busca todos os acessos de hoje
    @Query("SELECT a FROM Acesso a WHERE DATE(a.dataHora) = :data ORDER BY a.dataHora DESC")
    List<Acesso> findByData(@Param("data") LocalDate data);

    // Busca por refeição e data
    @Query("SELECT a FROM Acesso a WHERE DATE(a.dataHora) = :data AND a.refeicao = :refeicao ORDER BY a.dataHora DESC")
    List<Acesso> findByDataAndRefeicao(@Param("data") LocalDate data, @Param("refeicao") String refeicao);

    // Verifica se funcionário já registrou essa refeição hoje (duplicado)
    @Query("SELECT COUNT(a) > 0 FROM Acesso a WHERE a.matricula = :matricula AND a.refeicao = :refeicao AND DATE(a.dataHora) = :data AND a.resultado = 'Acesso OK'")
    boolean existsByMatriculaAndRefeicaoAndData(
            @Param("matricula") String matricula,
            @Param("refeicao") String refeicao,
            @Param("data") LocalDate data
    );

    // Busca por período
    List<Acesso> findByDataHoraBetweenOrderByDataHoraDesc(LocalDateTime inicio, LocalDateTime fim);

    // Total por refeição hoje
    @Query("SELECT a.refeicao, COUNT(a) FROM Acesso a WHERE DATE(a.dataHora) = :data AND a.resultado = 'Acesso OK' GROUP BY a.refeicao")
    List<Object[]> countByRefeicaoAndData(@Param("data") LocalDate data);
}
