# Sistema de Controle de Refeitório com Reconhecimento Facial
**Desenvolvido por: Gladson**

Sistema criado para resolver um problema real: um terminal de reconhecimento
facial (usado como catraca de refeitório) não possuía nenhum software para
receber, armazenar e exibir os dados de acesso registrados no equipamento.
Este projeto conecta o terminal à nuvem e disponibiliza um painel web de
acompanhamento em tempo real.

## Arquitetura

```
Terminal de reconhecimento facial (restaurante)
        ↓
agente_local.py (computador do restaurante)
        ↓ HTTP POST via internet
API Spring Boot (nuvem)
        ↓
PostgreSQL (nuvem)
        ↓
Painel Web (acessível de qualquer lugar)
```

O agente local consulta o terminal periodicamente, classifica cada acesso
por horário de refeição (café da manhã / almoço / jantar), evita duplicidade
e envia os registros para a API na nuvem, que os disponibiliza em um painel
web para o RH.

---

## 1. Deploy (exemplo usando Render)

### Passo 1 — Criar conta
Acesse a plataforma de nuvem de sua preferência (o `render.yaml` incluso
usa o [Render](https://render.com), que possui plano gratuito).

### Passo 2 — Criar banco PostgreSQL
1. Dashboard → New → PostgreSQL
2. Escolha um nome e o plano gratuito
3. Anote a **Connection String**

### Passo 3 — Deploy da API
1. Dashboard → New → Web Service
2. Conecte o repositório com este projeto
3. Configure:
   - **Build Command:** `mvn clean package -DskipTests`
   - **Start Command:** `java -jar target/refeitorio-1.0.0.jar`
4. Em Environment Variables, adicione:
   - `DATABASE_URL` = Connection String do banco
   - `API_SECRET_KEY` = gere uma chave secreta forte e aleatória (ex.: `openssl rand -hex 32`)
   - `RH_INITIAL_PASSWORD` = defina uma senha inicial forte para o usuário `rh`
5. Aguarde o deploy e anote a URL gerada

> ⚠️ **Nunca** reutilize valores de exemplo como chave secreta em produção.
> Gere uma chave nova para cada ambiente.

---

## 2. Configurar o Agente Local (Restaurante)

1. Copie `agente_local.py` para o computador do restaurante
2. Defina as variáveis de ambiente (ou edite as constantes no topo do
   arquivo, que servem apenas de fallback para testes locais):
   ```
   TERMINAL_IP=IP_DO_TERMINAL
   TERMINAL_SENHA=SENHA_DO_TERMINAL
   API_URL=https://SEU-APP.onrender.com
   API_KEY=<mesma chave definida em API_SECRET_KEY no deploy>
   TERMINAL_ID=RESTAURANTE-01
   ```
3. Instale as dependências:
   ```
   pip install requests
   ```
4. Execute:
   ```
   python agente_local.py
   ```

---

## 3. Acessar o Painel do RH

Abra o navegador e acesse a URL do serviço implantado. Funcionalidades:
- ✅ Visualizar acessos em tempo real
- ✅ Filtrar por data e refeição
- ✅ Exportar Excel com um clique
- ✅ Atualização automática a cada 30 segundos
- ✅ Totais por refeição

---

## 4. Adicionar novos terminais no futuro

Basta instalar o `agente_local.py` em outro computador, alterando:
```
TERMINAL_IP=IP_DO_NOVO_TERMINAL
TERMINAL_ID=RESTAURANTE-02
```
Os dados de todos os terminais chegam no mesmo banco e painel.

---

## Endpoints da API

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/acesso` | Recebe acesso do agente Python |
| GET | `/api/acessos/hoje` | Lista acessos de hoje |
| GET | `/api/acessos/totais` | Totais por refeição hoje |
| GET | `/api/exportar?data=YYYY-MM-DD` | Exporta Excel |
| GET | `/api/health` | Status da API |

---

## Tecnologias

- **Backend:** Java 21 + Spring Boot 3.2
- **Banco:** PostgreSQL
- **Frontend:** Thymeleaf + HTML/CSS/JS
- **Agente:** Python 3
- **Excel:** Apache POI
- **Segurança:** senha de usuário armazenada com hash BCrypt

## Notas sobre esta versão pública

Este repositório foi adaptado a partir de uma versão interna para servir
como amostra de portfólio: nomes de empresa, credenciais reais, IPs e a
logomarca original foram removidos ou substituídos por placeholders. Antes
de usar em um ambiente real, substitua o ícone em `static/img/` e gere
credenciais novas para o seu ambiente.
