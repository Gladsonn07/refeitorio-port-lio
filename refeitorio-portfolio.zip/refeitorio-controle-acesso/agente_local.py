# -*- coding: utf-8 -*-
"""
==============================================================
  AGENTE LOCAL — Sistema de Controle de Refeitório
  Desenvolvido por: Gladson
  Versão 3.1 — Correção de Fuso Horário e Trava Offline
==============================================================
"""

import os
import requests
import time
import sys
import logging
import winsound
from datetime import datetime, time as time_obj

# ==============================================================
#  CONFIGURAÇÕES — EDITE APENAS ESTE BLOCO
#  (em produção, prefira variáveis de ambiente em vez de
#   editar os valores diretamente no código)
# ==============================================================
TERMINAL_IP = os.getenv("TERMINAL_IP", "IP_DO_TERMINAL_AQUI")
SENHA       = os.getenv("TERMINAL_SENHA", "SENHA_DO_TERMINAL_AQUI")
API_URL     = os.getenv("API_URL", "https://SEU-APP.onrender.com")
API_KEY     = os.getenv("API_KEY", "SUA_CHAVE_SECRETA_AQUI")
TERMINAL_ID = os.getenv("TERMINAL_ID", "RESTAURANTE-01")
INTERVALO   = 5

# Janela total de operação
INICIO_OPERACAO = time_obj(5,  0)
FIM_OPERACAO    = time_obj(20, 0)

# Faixas de cada refeição
REFEICOES = {
    "Café da Manhã": (time_obj(5,  0), time_obj(8,  0)),
    "Almoço":        (time_obj(11, 0), time_obj(13, 0)),
    "Jantar":        (time_obj(18, 0), time_obj(20, 0)),
}
# ==============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(message)s",
    datefmt="%d/%m/%Y %H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("agente_log.txt", encoding="utf-8"),
    ]
)
log = logging.getLogger(__name__)

IDS_VISTOS   = set()
ULTIMO_INDEX = 0


# ── Sons ─────────────────────────────────────────────────────

def som_ok():
    try: winsound.Beep(1000, 200)
    except: pass

def som_duplicado():
    try:
        for _ in range(3):
            winsound.Beep(600, 150)
            time.sleep(0.05)
    except: pass

def som_desconhecido():
    try:
        winsound.Beep(400, 300)
        time.sleep(0.1)
        winsound.Beep(400, 300)
    except: pass

def som_fora_horario():
    """2 bipes longos — acesso fora do horário"""
    try:
        winsound.Beep(300, 500)
        time.sleep(0.1)
        winsound.Beep(300, 500)
    except: pass


# ── Helpers ──────────────────────────────────────────────────

def classificar_horario():
    agora = datetime.now().time()

    if agora < INICIO_OPERACAO or agora > FIM_OPERACAO:
        return None, None

    for nome, (inicio, fim) in REFEICOES.items():
        if inicio <= agora <= fim:
            return nome, "Acesso OK"

    return "Fora do Horário", "Fora do Horário"


# ── Terminal ─────────────────────────────────────────────────

def consultar_terminal(index):
    url     = f"http://{TERMINAL_IP}/api"
    payload = {"password": SENHA, "cmd": "getrtlog", "index": index}
    try:
        r = requests.post(url, json=payload, timeout=5)
        r.raise_for_status()
        return r.json()
    except requests.exceptions.ConnectionError:
        return None
    except requests.exceptions.Timeout:
        log.warning("⏱️  Terminal demorou para responder")
        return None
    except Exception as e:
        log.warning(f"⚠️  Erro no terminal: {e}")
        return None


# ── API Nuvem ─────────────────────────────────────────────────

def enviar_para_api(dados: dict) -> str:
    try:
        r = requests.post(
            f"{API_URL}/api/acesso",
            json=dados,
            headers={"X-API-Key": API_KEY},
            timeout=10
        )
        if r.status_code == 201:
            return r.json().get("resultado", "Acesso OK")
        else:
            log.error(f"❌ API retornou {r.status_code}: {r.text}")
            return "Erro"
    except requests.exceptions.ConnectionError:
        log.error("❌ Sem conexão com a nuvem.")
        return "Erro"
    except Exception as e:
        log.error(f"❌ Erro ao enviar: {e}")
        return "Erro"


# ── Processamento ─────────────────────────────────────────────

def processar(resp):
    global ULTIMO_INDEX

    if not resp or not resp.get("result"):
        return

    records = resp.get("record") or resp.get("data") or []
    if not isinstance(records, list) or not records:
        return

    for rec in records:
        uid = rec.get("index") or rec.get("time") or rec.get("id")
        if uid in IDS_VISTOS:
            continue
        IDS_VISTOS.add(uid)

        refeicao, resultado_horario = classificar_horario()

        if refeicao is None:
            log.info("⏭️  Fora da janela de operação — não enviado.")
            if isinstance(uid, int):
                ULTIMO_INDEX = max(ULTIMO_INDEX, uid + 1)
            continue

        tipo = str(rec.get("type", "0"))
        if resultado_horario == "Fora do Horário":
            resultado = "Fora do Horário"
        elif tipo in ("0", "verify", "normal"):
            resultado = "Acesso OK"
        elif tipo in ("1", "stranger"):
            resultado = "Desconhecido"
        else:
            resultado = f"Tipo {tipo}"

        nome      = rec.get("name") or rec.get("user_name") or "Desconhecido"
        matricula = str(rec.get("id") or rec.get("user_id") or "—")
        
        # Pega a hora exata do PC local e formata para o padrão que o Spring Boot entende
        agora_iso = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")

        payload = {
            "colaborador": nome,
            "matricula":   matricula,
            "refeicao":    refeicao,
            "resultado":   resultado,
            "terminalId":  TERMINAL_ID,
            "dataHoraEquipamento": agora_iso
        }

        resultado_final = enviar_para_api(payload)

        # Trava de Segurança Offline
        if resultado_final == "Erro":
            IDS_VISTOS.remove(uid)
            log.warning(f"⏳ Sem internet. O acesso de {nome} ficou na fila de espera.")
            break 

        if isinstance(uid, int):
            ULTIMO_INDEX = max(ULTIMO_INDEX, uid + 1)

        if resultado_final == "Acesso OK":
            log.info(f"✅ {nome:30s} | {refeicao:16s} | Acesso OK")
            som_ok()
        elif resultado_final == "Acesso Duplicado":
            log.warning(f"🔴 DUPLICADO: {nome} já registrou '{refeicao}' hoje!")
            som_duplicado()
        elif resultado_final == "Fora do Horário":
            log.warning(f"⚠️  FORA DO HORÁRIO: {nome} | {datetime.now().strftime('%H:%M:%S')}")
            som_fora_horario()
        else:
            log.warning(f"⚠️  {nome} — {resultado_final}")
            som_desconhecido()


# ── Main ──────────────────────────────────────────────────────

def main():
    global ULTIMO_INDEX

    print()
    print("=" * 58)
    print("   AGENTE LOCAL — SISTEMA DE REFEITÓRIO v3.1")
    print("   Desenvolvido por: Gladson")
    print("=" * 58)
    log.info(f"Terminal : http://{TERMINAL_IP}/api")
    log.info(f"Painel   : {API_URL}")
    log.info(f"Terminal ID: {TERMINAL_ID}")
    print("=" * 58)
    print()
    print("  Horários:")
    print("  ☕ Café da Manhã   — 05:00 às 08:00")
    print("  🍽️  Almoço          — 11:00 às 13:00")
    print("  🌙 Jantar           — 18:00 às 20:00")
    print("  ⚠️  Entre refeições — registra como Fora do Horário")
    print("  ⏭️  Antes das 05:00 e após 20:00 — não registra")
    print()
    print("  Sons:")
    print("  ✅ Acesso OK        — 1 bipe curto")
    print("  🔴 Acesso Duplicado — 3 bipes rápidos")
    print("  ⚠️  Fora do Horário — 2 bipes longos")
    print("  ⚠️  Desconhecido    — 2 bipes médios")
    print()
    print("=" * 58)

    log.info("🔌 Testando conexão com o terminal...")
    teste = consultar_terminal(0)
    if teste is None:
        log.warning("⚠️  Terminal não respondeu. Continuando...")
    else:
        log.info("✅ Terminal conectado!")
        records = teste.get("record") or []
        if records:
            ULTIMO_INDEX = len(records)
            log.info(f"   {ULTIMO_INDEX} registro(s) antigo(s) ignorado(s).")

    log.info("🌐 Testando conexão com o painel na nuvem...")
    try:
        r = requests.get(f"{API_URL}/api/health", timeout=10)
        if r.status_code == 200:
            log.info("✅ Painel na nuvem conectado!")
        else:
            log.warning(f"⚠️  Painel retornou {r.status_code}")
    except Exception:
        log.error("❌ Não foi possível conectar ao painel.")

    log.info("👁️  Monitorando... (CTRL+C para parar)\n")

    offline_terminal = False

    while True:
        try:
            resp = consultar_terminal(ULTIMO_INDEX)

            if resp is None:
                if not offline_terminal:
                    log.warning("📡 Terminal offline. Aguardando reconexão...")
                    offline_terminal = True
            else:
                if offline_terminal:
                    log.info("✅ Terminal reconectado!")
                    offline_terminal = False
                processar(resp)

        except KeyboardInterrupt:
            log.info("\n⏹  Agente encerrado.")
            break
        except Exception as e:
            log.error(f"Erro inesperado: {e}")

        time.sleep(INTERVALO)


if __name__ == "__main__":
    main()
